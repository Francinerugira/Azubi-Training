<?php 

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $country = $_POST['country'];
    $dob = $_POST['dob'];

    
    $form_data = array(
        array(
            'name' => $name,
            'email' => $email,
            'date of birth' => $dob,
            'gender' => $gender,
            'country' => $country,
        )
       
    );

    $file_open = fopen("userdata.csv", "a");
    fputcsv($file_open, $data);
    fclose($file_open);
    
    $result = print_r($_POST);

}

?>
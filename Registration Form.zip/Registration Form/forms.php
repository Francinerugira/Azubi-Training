<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forms</title>
</head>
<body>
    <form action="user_data.php" method="post">
        <label for="name">Name: </label><input type="text" name="name" required><br>
        <label for="email">Email: </label><input type="email" name="email" required><br>
        <label for="dob">Date Of Birth:</label><input type="date" name="dob" required><br>
        <label for="gender">Gender</label><br>
        <input type="radio" name="gender" required value="Female"> Female
        <input type="radio" name="gender" required value="Male"> Male<br>
        <label for="country">Country</label><input type="text" name="country" required><br>
        <input type="submit" name="submit" required value="Submit">
    </form>
</body>
</html>
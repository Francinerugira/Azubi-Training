In the task description you tell me to do a rest password but you did not tell me where
to put a link and i thought that i can do it in two different ways; first in landing page
before login and in landing page after login. So that why i have two different resetpassword
files for both forms folder and php folder.
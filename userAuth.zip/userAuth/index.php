<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link rel="stylesheet" href="assets/style.css">

</head>
<body>
    <center><p><b>Welcome To this page</b></p></center> <br>
    <p><a href="forms/register.html">Register</a></p>
    <p><a href="forms/login.html">Login</a></p>
    <p><a href="forms/resetpassword_1.html">Reset Password</a></p>
</body>
</html>
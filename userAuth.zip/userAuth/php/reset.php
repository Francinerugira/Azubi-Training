<?php 
session_start();
$email = $_SESSION['email'];
if(isset($_POST['submit'])){
    
    $password = $_POST['password'];

    $file_read = fopen("../storage/users.csv", "r");
    $file_write = fopen("../storage/temporary.csv", "w");
    while(($data = fgetcsv($file_read)) !== FALSE){
    if($data[1] == $email){
        $data[2] = $password;
        echo '<script>
 alert(" Successfull change password");
window.location.href="../forms/resetpassword.html";
</script>';
    }else{
       echo '<script>
 alert(" Sorry user does not exit");
window.location.href="../forms/resetpassword.html";
</script>';
    }
    fputcsv($file_write, $data);

}

fclose($file_read);
fclose($file_write);

unlink('../storage/users.csv');
rename('../storage/temporary.csv', '../storage/users.csv');

}
    

?>
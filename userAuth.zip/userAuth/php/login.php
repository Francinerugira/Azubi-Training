<?php 

if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];


    $file = fopen("../storage/users.csv", "r");
    while(($line = fgetcsv($file)) !== FALSE){
        if($line[1] == $email && $line[2] == $password ){
            $success = true;
            break;
        }
    }
    fclose($file);
    if ($success) {
        session_start();
	    $_SESSION['email'] = $email;
	    $_SESSION['password']     = $password;
        session_write_close();
        header("location: ../dashboard.php");
    }else{
        echo '<script>
        alert(" Sorry... Email Or Password is incorrect");
        window.location.href="../forms/login.html";
        </script>';
    }
}

?>
<?php 

if(isset($_POST['submit'])){
    $name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    
    $form_data = array(
            'full_name' => $name,
            'email' => $email,
            'password' => $password,
       
    );
    $file = fopen("../storage/users.csv", "r");
    while(($line = fgetcsv($file)) !== FALSE){
    if($line[1] == $email){
        $success = true;
        break;
    }else{
        $success = false;
    }
    
}
if ($success) {
    echo '<script>
 alert(" Sorry... Email already Exist");
window.location.href="../forms/register.html";
</script>';
}else{
    $file_open = fopen("../storage/users.csv", "a");
    $save = fputcsv($file_open, $form_data);
    fclose($file_open);
    
    if($save){
        echo '<script>
 alert(" User Successfull Registered");
window.location.href="../forms/register.html";
</script>';
    }

}
}
    

?>